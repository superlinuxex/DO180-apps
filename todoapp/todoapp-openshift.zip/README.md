# TodoApp OpenShift
Aplicación TodoApp con Node.js y MySQL lista para desplegar en OpenShift.
