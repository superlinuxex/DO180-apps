#!/bin/bash
npm install
