# TodoApp Node.js
Aplicación de ejemplo para gestionar tareas con Node.js y MySQL.